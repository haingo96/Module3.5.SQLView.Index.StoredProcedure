create
    definer = root@localhost procedure getAllProduct()
begin
    select * from product;
end;

