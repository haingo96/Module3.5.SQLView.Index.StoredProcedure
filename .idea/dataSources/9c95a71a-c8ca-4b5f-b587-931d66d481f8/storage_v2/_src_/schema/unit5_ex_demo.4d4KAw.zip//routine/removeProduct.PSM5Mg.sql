create
    definer = root@localhost procedure removeProduct(IN productId int)
begin
        delete from product where id = productId;
    end;

