create
    definer = root@localhost procedure editProduct(IN productId int, IN productC int, IN productN varchar(20))
begin
        update product
            set productCode = productC, productName = ProductN
        where id = productId;
    end;

