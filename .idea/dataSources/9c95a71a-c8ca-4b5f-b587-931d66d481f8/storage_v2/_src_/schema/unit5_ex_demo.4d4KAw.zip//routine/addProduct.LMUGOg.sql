create
    definer = root@localhost procedure addProduct(IN productC int, IN productN varchar(20))
begin
        insert into product (productCode, productName)
            values (productC, productN);
    end;

