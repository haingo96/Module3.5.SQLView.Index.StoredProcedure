create
    definer = root@localhost procedure findCustomerByFirstName(IN name varchar(20))
begin
    select * from customers where contactFirstName = name;
end;

