create definer = root@localhost view customer_view as
select `classicmodels`.`customers`.`customerNumber` AS `customerNumber`,
       `classicmodels`.`customers`.`customerName`   AS `customerName`
from `classicmodels`.`customers`
where (`classicmodels`.`customers`.`customerNumber` < 250);

