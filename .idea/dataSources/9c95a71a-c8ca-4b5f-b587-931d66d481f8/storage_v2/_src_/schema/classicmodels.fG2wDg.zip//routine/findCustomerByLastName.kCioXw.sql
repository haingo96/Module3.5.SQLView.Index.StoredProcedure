create
    definer = root@localhost procedure findCustomerByLastName(IN lastName varchar(20), OUT foundCustomer varchar(20))
begin
    select contactLastName
    into foundCustomer
    from customers
    where contactLastName = lastName;
end;

