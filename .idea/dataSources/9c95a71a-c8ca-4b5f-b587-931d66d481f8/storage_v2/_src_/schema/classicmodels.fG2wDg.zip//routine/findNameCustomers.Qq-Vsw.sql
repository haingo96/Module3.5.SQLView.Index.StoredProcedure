create
    definer = root@localhost procedure findNameCustomers()
BEGIN
    SELECT customerName FROM customers;
end;

